setTimeout(() => {
    console.log("se demora 2 seg")
}, 2000);

setTimeout(() => {
    console.log("se demora 1 seg")
}, 1000);