exports.area = (a, b) => (a * b);
exports.perimetro = (a, b) => (2 * (a + b));